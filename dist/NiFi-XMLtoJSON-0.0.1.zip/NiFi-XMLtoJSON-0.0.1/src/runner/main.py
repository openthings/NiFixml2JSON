from src.xml2json import conversion
import os, sys

if __name__ == "__main__":
    for file_name in os.listdir('/test123'):
        a = open("/test123" + file_name, 'r').read()
        b = conversion.Conversion(a)
        c = b.xml_to_json()
        print c.replace("{http://www.cgi.com/Ratabase}", '')
        sys.stdout.write(c.replace("{http://www.cgi.com/Ratabase}", ''))
        os.remove("/test123/" + file_name)
