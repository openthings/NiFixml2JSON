xml2csv is a Python Module that makes working with and XML file in HDFS much easier.
It converts the expensive XML file to a JSON file structure in order to achieve better
Apache Hive Manipulation.

Place on NiFi node
Create a ExecuteStreamCommand Processor
Configure Processor to Invoke the Python Module
NiFi will then send the STDIN to the Python Module
The Python Module will Exhume the Converted File
BOOM!
JSON File is Now in the Stream